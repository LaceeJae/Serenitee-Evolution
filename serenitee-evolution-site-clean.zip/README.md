# Serenitee Evolution Studio Website

This package contains your full website with:
- Booking calendar (hourly slots, 9 AM–9 PM)
- PayPal $35 deposit button
- Google Sheets + PayPal IPN integration
- Sample Google Sheet CSV for setup
- Demo booked slots (Sept 2025)

## Setup Steps
1. Create a Google Sheet and import `sample_bookings.csv`.
2. Open Extensions → Apps Script, paste code from `apps_script.gs`, deploy as Web App.
3. Paste your Web App URL into `script.js` (replace PASTE_YOUR_URL_HERE).
4. Enable PayPal IPN and use the same Web App URL as listener.
5. Deploy site on Cloudflare Pages.

Enjoy!
